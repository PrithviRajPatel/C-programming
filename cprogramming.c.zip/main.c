/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int swap(int a, int b);
int main()
{
    
    int a=10,b=20;
    a,b=swap(a,b);
    
}
int swap (int x, int y){
    int temp;
    temp=x;
    x=y;
    y=temp;
    printf("swap of two number a and b is %d and %d",x,y);
    return 0;
    
}