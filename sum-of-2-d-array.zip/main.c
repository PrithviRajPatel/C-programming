#include<stdio.h>
void main(){
    
    int arr[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    int brr[3][3]={{10,20,30},{40,50,60},{70,80,90}};
   
    int crr[3][3];
     int i,j;
   
    
    for (i=0;i<3;i++){
        for(j=0;j<3;j++){
            crr[i][j]=arr[i][j]+brr[i][j];
            printf("\n");
             
            
            
        }
         printf("\n");
    }
    
    for (i=0;i<3;i++){
        for(j=0;j<3;j++){
            printf("%d\t",crr[i][j]);
            
        }
        printf("\n");
    }

}