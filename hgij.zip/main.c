#include <stdio.h>
#include <string.h>

int main()

    char str1[]="Hello prithvi";
    char *substring=strstr(str1,"ello");
    if(substring){
        printf("\nfound substring at the pos of %d",substring - str1);
    }
    else{
        printf("not found");
    }
}