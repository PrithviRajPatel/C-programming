/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void main(){
    int a=10;
    int *addr =&a;
    printf("value of a is %d\n",a);
    printf("add of a is %p", addr);
}

