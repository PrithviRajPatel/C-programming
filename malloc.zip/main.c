
#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
    int *ptr,i,value=0;
     ptr = (int *)malloc(5*sizeof(int));
    if (ptr==NULL){
        printf("allocation is not possible");
    }
   
    for (i=0;i<5;i++){
        value=value+10;
        ptr[i]=value;
    }
    for (i=0;i<5;i++){
        printf(" %d value is: %d\n",i+1,ptr[i]);
    }
    
}
