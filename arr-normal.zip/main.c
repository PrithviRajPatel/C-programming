/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void main(){
    int arr[5]={10,20,30,40,50};
    printf("index 0 value is %d\n",arr[0]);
    printf("index 1 value is %d\n",arr[1]);
    printf("index 2 value is %d\n",arr[2]);
    printf("index 3 value is %d\n",arr[3]);
    printf("index 4 value is %d",arr[4]);
}
      