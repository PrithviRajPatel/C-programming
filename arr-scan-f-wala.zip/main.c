/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<math.h>
#include<string.h>

void main()
{
    int arr[5]={100,200,300,400,500};
    int *ptr=arr;
    printf(" value of ptr is %d",*ptr);
}
    