#include <stdio.h>
void main(){
    int arr[7]={10,20,25,30,40,50,70}, 
    int key=25;
   int result=b_search(arr,key);
    if (result!=-1) {
        printf("Element is present at index %d\n", result);
        }
        else {
            printf("Element is not present in the array\n");
            
}
}
int b_search(int arr[],int key){
    int low=0, high=6, mid;
    while(low<=high){
        mid=(low+high)/2;
        if(arr[mid]==key){
            return mid;
        }
        else if(arr[mid]<key){
            low=mid+1;
            
        }
        else{ 
            high=mid-1;
        }
        
     
}
   return -1;
}
    
