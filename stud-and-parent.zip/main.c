#include <stdio.h>
struct Parent{
    char p_name[15];
    long p_ph;
};
struct CSE{
    int RollNo;
    char Name[20];
    int marks;
    struct Parent par;
};

int main(){
    struct CSE s1={143,"vjvfhfh",76,{"jhhug",6556798}};
    printf("\nrollno is %d",s1.RollNo);
    printf("\nname is %s",s1.Name);
    printf("\nmarks is %d",s1.marks);
    printf("\nparent name is %s",s1.par.p_name);
    printf("\nparent ph no is %ld",s1.par.p_ph);
    }
   