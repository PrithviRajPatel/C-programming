/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void swap (int *x, int *y){
    int temp;
    temp=*x;
    *x=*y;
    *y=temp;
    
    return;
    
}
int main()
{
    int a=10;
    int b=20;
  
    swap(&a,&b);
    printf("swap of two number a and b is %d and %d",a,b);
    return 0;
}


