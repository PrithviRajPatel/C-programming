/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int fact(int x){
    if(x==1){
        return 1;
    }
    else{
        return (x*fact(x-1));
    }
    
}
int main(){
    int num=5,total;
    total = fact(num);
    printf("fact of the num %d is %d",num,total);
    return 0;
}