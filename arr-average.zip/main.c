/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void main()
{
    int arr[5]={10,20,30,40,50},i,sum=0,avg;
    for(i=0;i<=4;i++){
        sum=sum+arr[i];
        

    }
    avg=sum/i+1;
    printf("average of number is %d\n",avg);
}