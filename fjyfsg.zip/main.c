#include<stdio.h>
struct student {
    int R_no[2];
    char name[2][20];
    int marks[2];
    
};
int main(){
    struct student s[3];
    for (int i=0;i<2;i++){
        printf("\nenter %d r no:",i+1);
        scanf("%d",&s[i].R_no);
        printf("\nenter %s name:",i+1);
        scanf("%s",&s[i].name);
        printf("\nenter %d marks:",i+1);
        scanf("%d",&s[i].marks);
        
        
        
        
        for (int i=0;i<2;i++){    
        printf("\nrollno is %d,name is %s,marks are %d",s[i].R_no,s[i].name,s[i].marks);
    }
}
}