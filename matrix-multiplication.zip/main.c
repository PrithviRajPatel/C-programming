#include<stdio.h>
void main(){
    
    int arr[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    int brr[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    
    int crr[3][3];
     int i,j,k,sum=0;
     
   
    
    for (i=0;i<3;i++){
        for(j=0;j<3;j++){
            for(k=0;k<3;k++){
               crr[i][j] =crr[i][j]+(arr[i][k]*brr[k][j]);
               
    
                
            }
            
        }
        
       // crr[i][j]=sum;
    }
    
    
         
    
    for (i=0;i<3;i++){
        for(j=0;j<3;j++){
            printf("%d\t", crr[i][j]);
            
        }
        printf("\n");
    }

}