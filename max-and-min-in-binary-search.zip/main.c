#include <stdio.h>

int b_search(int arr[], int key);

void main() {
    int arr[5] = {2,7,1,9,5},i,max,min;
    max=arr[0];
    min=arr[0];
    for(i=0;i<5;i++){
        if (arr[i]<=min){
            min=arr[i];
        }
        else if(arr[i]>max){
            max=arr[i];
        }
    }
    printf("max value is %d and min value is %d",max,min);
}
                                                         
   

