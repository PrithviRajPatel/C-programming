#include <stdio.h>


void main()
{
    int arr[7]={10,50,30,20,70,25,40},i,flag=0,key=25;
    printf("enter the search key");
    scanf("%d",&key);
    for(i=0;i<7;i++){
        if(key==arr[i]){
            flag=1;
            printf("key is present");
            break;
        }
    }
    if(flag==0){
        printf("number is absent");
    }
}