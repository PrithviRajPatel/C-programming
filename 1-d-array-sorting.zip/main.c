#include<stdio.h>
void main(){
    int arr[5]={2,7,1,9,5},j,i,temp;
    for(i=0;i<5;i++){
        for (j=1;j<5;j++){
            if(arr[j]<arr[i]){
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
                
                
            }
        }
    }
    printf("\n");
    for (i=0;i<5;i++){
        printf(" %d\t",arr[i]);
    }
}