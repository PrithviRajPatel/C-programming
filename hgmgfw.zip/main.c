#include <stdio.h>
struct CSE{
    int RollNo;
    char Name[8];
    double ph;
};
int main(){
    struct CSE s1={101,"Prithvi", 9999999999};
    printf("RollNo is %d",s1.RollNo);
    printf("\n Name is %s",s1.Name);
    printf("\n ph is %.0lf",s1.ph);
    struct CSE s2={102,"Sahil",8888888888};
    printf("\nRollNo is %d",s2.RollNo);
    printf("\n Name is %s",s2.Name);
    printf("\n ph is %.0lf",s2.ph);
    
    
}