/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int fab(int x){
    if(x==0){
        return 0;
    }
    else if(x==1){
        return 1;
        
    }
    else{
        return (fab(x-1)+fab(x-2));
    }
}
    
    

int main(){
    int num=0,total;
    total = fab(num);
    printf("fab of the num %d is %d",num,total);
    return 0;
}