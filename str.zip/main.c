
#include <stdio.h>
#include <string.h>

int main()
{
    char str1[]="Hello\0";
    char str2[10];
    strncpy(str2,str1,2);
    printf("\n%s",str2);
}
